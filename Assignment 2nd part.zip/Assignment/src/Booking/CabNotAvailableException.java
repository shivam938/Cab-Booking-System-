package Booking;

	public class CabNotAvailableException extends Exception{
		 public CabNotAvailableException(String message) {
		        super(message);
		    }
	}
