
public class CarNotAvailable extends Exception {
	
	public CarNotAvailable(String message) {
		super(message);
	}
}
